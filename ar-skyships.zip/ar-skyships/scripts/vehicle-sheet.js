class VehicleSheet extends ActorSheet {
  get template() {
    return "modules/ar-skyships/templates/vehicle-sheet.html";
  }

  getData() {
    const data = super.getData();
    data.attributes = this.actor.data.data.attributes;
    return data;
  }
}

Actors.registerSheet("pf1", VehicleSheet, { types: ["vehicle"], makeDefault: true });

Hooks.once("init", function() {
  console.log("Custom Vehicle Actor | Initializing custom vehicle actor sheet");

  CONFIG.Actor.entityClass = VehicleSheet;

  Actors.unregisterSheet("core", ActorSheet);
  Actors.registerSheet("pf1", VehicleSheet, { types: ["vehicle"], makeDefault: true });
});